// Tests: node tests/test-parse.js  (liest den Kern-Script aus index.html)
const fs = require("fs"), path = require("path"), vm = require("vm"), assert = require("assert");
const html = fs.readFileSync(path.join(__dirname, "..", "index.html"), "utf8");
const core = html.match(/<script id="core">([\s\S]*?)<\/script>/)[1];
const ctx = { module: { exports: {} }, Intl, Date, JSON, Math, String, parseFloat, isNaN, isFinite, URL, Object };
vm.createContext(ctx); vm.runInContext(core, ctx); const SR = ctx.module.exports;
let n = 0; const t = (name, fn) => { fn(); n++; console.log("✔", name); };
const now = 1795000000;

t("grüner Schatz (Text)", () => {
  const d = SR.parseMessage({event:"message",id:"a",time:now,title:"💎 SCHATZ GEFUNDEN – Lenovo M720q",
    message:"🟢 **Ampel:** Grün\n💶 **Preis:** 22 € inkl. Versand\n📈 **Gewinn netto:** ca. 45 €\n🔧 **Defekt:** ohne RAM/SSD\n📍 **Quelle:** Kleinanzeigen · Versand",
    click:"https://www.kleinanzeigen.de/s-anzeige/x", attachment:{url:"https://img.example/a.jpg"}});
  assert.strictEqual(d.geraet,"Lenovo M720q"); assert.strictEqual(d.preis,22); assert.strictEqual(d.gewinn,45);
  assert.strictEqual(d.defekt,"ohne RAM/SSD"); assert.strictEqual(d.plattform,"Kleinanzeigen"); assert.strictEqual(d.ampel,"gruen");
  assert.strictEqual(d.link,"https://www.kleinanzeigen.de/s-anzeige/x"); assert.strictEqual(d.bild,"https://img.example/a.jpg");
  assert.strictEqual(SR.isMega(d,100),false); assert.strictEqual(d.abholung,false);
});
t("Mega-Schatz Titel + Komma-Preis", () => {
  const d = SR.parseMessage({id:"b",time:now,title:"🔥💎 MEGA-SCHATZ – ThinkPad T480s",message:"**Preis:** 85,50 €\n**Gewinn netto:** ca. 1.125 €\n**Quelle:** eBay"});
  assert.strictEqual(d.geraet,"ThinkPad T480s"); assert.strictEqual(d.preis,85.5); assert.strictEqual(d.gewinn,1125); assert.ok(SR.isMega(d,100));
});
t("Mega über Gewinn > 100", () => {
  const d = SR.parseMessage({id:"c",time:now,title:"💎 SCHATZ GEFUNDEN – PS5 Board",message:"**Preis:** 40 €\n**Gewinn netto:** 130 €"});
  assert.ok(SR.isMega(d,100));
});
t("gelb über 🟡-Titel", () => {
  const d = SR.parseMessage({id:"d",time:now,title:"🟡 Mal anschauen – Dell 7070 Micro",message:"**Preis:** 60 €\n**Gewinn netto:** ca. 28 €"});
  assert.strictEqual(d.ampel,"gelb"); assert.strictEqual(d.geraet,"Dell 7070 Micro");
});
t("Abholung Dörpen erkannt", () => {
  const d = SR.parseMessage({id:"e",time:now,title:"💎 SCHATZ GEFUNDEN – Akkuschrauber",message:"**Preis:** 10 € (Abholung Dörpen)\n**Gewinn netto:** 30 €\n**Quelle:** Kleinanzeigen"});
  assert.strictEqual(d.abholung,true);
});
t("Testnachrichten ausgeblendet", () => {
  const msgs = [
    {title:"💎 Schatz-Test",message:"Testfund: Lenovo M720q defekt, 22 €"},
    {title:"✅ ntfy-Check",message:"Check 06:44"},
    {title:"💎 SCHATZ GEFUNDEN – Lenovo M720q",message:"**DESIGN-MUSTER (kein echter Fund)**\n**Preis:** 22 €\n**Gewinn netto:** 45 €"},
    {message:"Funktioniert"},
    {event:"keepalive"},
    {title:"💎 SCHATZ GEFUNDEN – X",message:"**Preis:** 1 €\n**Gewinn netto:** 5 €\nkein echter Fund"}
  ];
  msgs.forEach(m => assert.strictEqual(SR.parseMessage(m), null, JSON.stringify(m)));
});
t("DATA:-JSON hat Vorrang", () => {
  const d = SR.parseMessage({id:"f",time:now,title:"💎 SCHATZ GEFUNDEN – Text-Gerät",
    message:"**Preis:** 99 €\n**Gewinn netto:** 1 €\nDATA: {\"geraet\":\"HP EliteDesk 800 G4\",\"preis\":30,\"gewinn\":52,\"defekt\":\"Netzteil fehlt\",\"quelle\":\"Kleinanzeigen · Abholung Dörpen\",\"link\":\"https://example.org/x\",\"ampel\":\"gelb\",\"ende\":\"2026-11-18T18:00:00+01:00\"}"});
  assert.strictEqual(d.geraet,"HP EliteDesk 800 G4"); assert.strictEqual(d.preis,30); assert.strictEqual(d.gewinn,52);
  assert.strictEqual(d.ampel,"gelb"); assert.strictEqual(d.link,"https://example.org/x"); assert.strictEqual(d.abholung,true);
  assert.strictEqual(d.ende, Date.parse("2026-11-18T18:00:00+01:00")/1000); assert.ok(d.viaData);
});
t("DATA ohne Titel-Format", () => {
  const d = SR.parseMessage({id:"g",time:now,message:"DATA: {\"geraet\":\"Switch Board\",\"preis\":\"35 €\",\"gewinn\":\"ca. 38 €\",\"ampel\":\"grün\"}"});
  assert.strictEqual(d.geraet,"Switch Board"); assert.strictEqual(d.preis,35); assert.strictEqual(d.gewinn,38); assert.strictEqual(d.ampel,"gruen");
});
t("rote Funde & unsichere Links verworfen", () => {
  assert.strictEqual(SR.parseMessage({id:"h",time:now,title:"💎 SCHATZ GEFUNDEN – Y",message:"**Ampel:** Rot\n**Preis:** 5 €\n**Gewinn netto:** 2 €"}), null);
  const d = SR.parseMessage({id:"i",time:now,title:"💎 SCHATZ GEFUNDEN – Z",message:"DATA: {\"link\":\"javascript:alert(1)\",\"preis\":1,\"gewinn\":9}"});
  assert.strictEqual(d.link, null);
});
t("Endet bald (Titel ⏰ / Endet-Zeile)", () => {
  const d = SR.parseMessage({id:"j",time:now,title:"⏰ Endet in 30 Min – Switch Board",message:"**Preis:** 35 €\n**Gewinn netto:** 38 €"});
  assert.strictEqual(d.ende, now+1800); assert.ok(SR.endetBald(d, now+60)); assert.ok(!SR.endetBald(d, now+4000));
  const e = SR.parseMessage({id:"k",time:now,title:"💎 SCHATZ GEFUNDEN – A",message:"**Preis:** 3 €\n**Gewinn netto:** 40 €\n**Endet:** in 2 Std 15 Min"});
  assert.strictEqual(e.ende, now+8100);
});
t("toNum", () => {
  assert.strictEqual(SR.toNum("ca. 45 €"),45); assert.strictEqual(SR.toNum("1.234,50 €"),1234.5);
  assert.strictEqual(SR.toNum("22,5"),22.5); assert.strictEqual(SR.toNum("12.5"),12.5); assert.strictEqual(SR.toNum("–"),null);
});
t("nächste Suchrunde (Europe/Berlin)", () => {
  const at = iso => SR.nextRound(new Date(iso));
  assert.deepStrictEqual([at("2026-11-18T07:13:00+01:00").label, at("2026-11-18T07:13:00+01:00").inSec],["08:13",3600]);
  assert.strictEqual(at("2026-11-18T08:13:00+01:00").label,"13:13");
  assert.strictEqual(at("2026-11-18T20:00:00+01:00").label,"22:13");
  const m = at("2026-11-18T23:00:00+01:00"); assert.strictEqual(m.label,"08:13"); assert.ok(m.morgen); assert.strictEqual(m.inSec, 9*3600+13*60);
  assert.strictEqual(at("2026-07-01T07:13:00+02:00").inSec, 3600); // Sommerzeit
  assert.ok(SR.isNight(new Date("2026-11-18T23:30:00+01:00"))); assert.ok(!SR.isNight(new Date("2026-11-18T12:00:00+01:00")));
});
t("Max-Preis-Rechner", () => {
  const base = {verkauf:220,teilewert:60,unklar:false,gebuehr:13,versandRein:6,versandRaus:6,ersatzteile:30,stunden:1.5,stundensatz:15,kollege:25,wunsch:40};
  const r = SR.calc(base);
  // Erlös 220*0.87-6 = 185.4; direkt 36; (40+22.5)/0.75 = 83.333 -> max 66.07
  assert.ok(Math.abs(r.maxEk - 66.0667) < 0.01, r.maxEk);
  assert.ok(Math.abs(r.dein - r.lohn - 40) < 0.01); // bei Max-Preis bleibt genau Wunschgewinn nach Stundenlohn
  const u = SR.calc(Object.assign({}, base, {unklar:true})); // 0.6*220+0.4*60=156
  assert.ok(Math.abs(u.erwartet - 156) < 1e-9); assert.ok(u.maxEk < r.maxEk);
  const a = SR.calc(Object.assign({}, base, {angebot:22})); // roh=185.4-36-22=127.4, dein=95.55, /1.5=63.7
  assert.strictEqual(a.ampel,"gruen"); assert.ok(Math.abs(a.proStd-63.7)<0.01);
  const b = SR.calc(Object.assign({}, base, {angebot:140})); assert.strictEqual(b.ampel,"rot");
  const c = SR.calc(Object.assign({}, base, {angebot:115})); // roh 34.4 -> dein 25.8 -> 17.2/h
  assert.strictEqual(c.ampel,"gelb");
});
// ---------- Review-Fixes (18.11.2026) ----------
const M = (title, message, extra={}) => Object.assign({event:"message", id:Math.random().toString(36).slice(2), time:now, title, message}, extra);
t("Fix 1: isTest nur ganze Wörter", () => {
  ["💎 SCHATZ GEFUNDEN – ThinkPad T480 getestet","💎 SCHATZ GEFUNDEN – LAN-Kabeltester","💎 SCHATZ GEFUNDEN – Batterietester Profi",
   "💎 SCHATZ GEFUNDEN – Checkpoint Router","💎 SCHATZ GEFUNDEN – Testo 830 Thermometer","💎 SCHATZ GEFUNDEN – Mustergerät Laptop"].forEach(tt => {
    assert.ok(SR.parseMessage(M(tt,"**Preis:** 20 €\n**Gewinn netto:** 40 €")), "verworfen: "+tt);
  });
  ["💎 Schatz-Test","✅ ntfy-Check","Team-Test","💎 SCHATZ GEFUNDEN – Test","Check 06:44","DESIGN-MUSTER – Lenovo"].forEach(tt => {
    assert.strictEqual(SR.parseMessage(M(tt,"**Preis:** 20 €\n**Gewinn netto:** 40 €")), null, "nicht ausgeblendet: "+tt);
  });
  assert.strictEqual(SR.parseMessage(M("💎 SCHATZ GEFUNDEN – A","**Preis:** 2 €\n**Gewinn netto:** 4 €\n(kein echter Fund)")), null);
  assert.ok(SR.parseMessage(M("💎 SCHATZ GEFUNDEN – A","**Preis:** 2 €\n**Gewinn netto:** 4 €\n**Defekt:** getestet, Akku schwach")));
});
t("Fix 2: Erinnerung wird zusammengeführt, nicht doppelt gezählt", () => {
  const link = "https://www.kleinanzeigen.de/s-anzeige/123";
  const orig = SR.parseMessage(M("🔥💎 MEGA-SCHATZ – MacBook Board","**Preis:** 60 €\n**Gewinn netto:** 180 €",{click:link}));
  const rem  = SR.parseMessage(M("⏰ Endet in 30 Min – MacBook Board","**Preis:** 60 €\n**Gewinn netto:** 180 €",{click:link+"/", time:now+600}));
  assert.strictEqual(rem.ampel,"offen", "Erinnerung ohne Ampel darf nicht grün sein");
  assert.strictEqual(SR.isMega(rem,100), false);
  assert.strictEqual(orig.key, rem.key);
  const deals = {}; let neu = 0;
  [orig, rem].forEach(d => { const r = SR.mergeDeal(deals[d.key], d); deals[d.key] = r.deal; if (r.neu) neu++; });
  assert.strictEqual(Object.keys(deals).length, 1); assert.strictEqual(neu, 1);
  const d = deals[orig.key];
  assert.strictEqual(d.ampel,"gruen"); assert.strictEqual(d.ende, now+600+1800); assert.ok(SR.endetBald(d, now+700));
  const sum = Object.values(deals).reduce((s,x)=>s+(x.ampel==="gruen"?x.gewinn:0),0); assert.strictEqual(sum,180);
  // umgekehrte Reihenfolge: Erinnerung zuerst, dann Original → 1 Fund, grün, Endzeit bleibt
  const d2 = {}; [rem, orig].forEach(x => { const r = SR.mergeDeal(d2[x.key], x); d2[x.key] = r.deal; });
  assert.strictEqual(Object.keys(d2).length,1); assert.strictEqual(Object.values(d2)[0].ampel,"gruen"); assert.strictEqual(Object.values(d2)[0].ende, now+2400);
  // ohne Link: Gerät+Quelle
  const a = SR.parseMessage(M("💎 SCHATZ GEFUNDEN – Lenovo M720q","**Preis:** 22 €\n**Gewinn netto:** 45 €\n**Quelle:** eBay"));
  const b = SR.parseMessage(M("⏰ Endet in 10 Min – Lenovo M720q","**Quelle:** eBay"));
  assert.strictEqual(a.key, b.key);
  // Erinnerung mit Ampel behält ihre Ampel
  assert.strictEqual(SR.parseMessage(M("⏰ Endet in 10 Min – X","**Ampel:** Gelb")).ampel, "gelb");
});
t("Fix 3: Vorzeichen beim Gewinn", () => {
  const d = SR.parseMessage(M("🟡 Mal anschauen – Y","**Preis:** 50 €\n**Gewinn netto:** -12 €"));
  assert.strictEqual(d.gewinn,-12);
  assert.strictEqual(SR.eurSigned(-12),"−12 €"); assert.strictEqual(SR.eurSigned(45),"+45 €"); assert.strictEqual(SR.eurSigned(1234.5,2),"+1.234,50 €");
  assert.strictEqual(SR.eur(-20.28,2),"−20,28 €"); assert.ok(!SR.eurSigned(-12).includes("+"));
});
t("Fix 4: Bild-URL nur https und ausbruchsicher", () => {
  assert.strictEqual(SR.safeImageUrl("http://x.de/a.jpg"), null);
  assert.strictEqual(SR.safeImageUrl("javascript:alert(1)"), null);
  assert.strictEqual(SR.safeImageUrl("data:image/png;base64,AAAA"), null);
  const u = SR.safeImageUrl("https://img.example/a'b(c)\").jpg?x=1 2");
  assert.ok(u.startsWith("https://img.example/")); assert.ok(!/['"()\s\\]/.test(u), u);
  const d = SR.parseMessage(M("💎 SCHATZ GEFUNDEN – Z","**Preis:** 1 €\n**Gewinn netto:** 9 €",{attachment:{url:"https://i.ytimg.com/vi/x'y/hq.jpg"}}));
  assert.ok(!d.bild.includes("'")); assert.ok(d.bild.includes("%27"));
  assert.strictEqual(SR.parseMessage(M("💎 SCHATZ GEFUNDEN – Z","**Preis:** 1 €\n**Gewinn netto:** 9 €",{attachment:{url:"http://unsicher.de/a.jpg"}})).bild, null);
});
t("Fix 5: exakter Feldname", () => {
  const d = SR.parseMessage(M("💎 SCHATZ GEFUNDEN – Z","**Preis neu:** 400 €\n**Preis:** 30 €\n**Gewinn netto:** 50 €\n**Gewinn brutto:** 90 €"));
  assert.strictEqual(d.preis,30); assert.strictEqual(d.gewinn,50);
  const e = SR.parseMessage(M("💎 SCHATZ GEFUNDEN – Z","**Gewinn brutto:** 90 €\n**Gewinn:** 41 €\n**Preis inkl. Versand:** 12 €"));
  assert.strictEqual(e.gewinn,41); assert.strictEqual(e.preis,12);
});
t("Fix 6: Ende als Unix-Zeit-String", () => {
  assert.strictEqual(SR.parseEnde("1763486400", now), 1763486400);
  assert.strictEqual(SR.parseEnde("1763486400000", now), 1763486400);
  assert.strictEqual(SR.parseEnde(1763486400000, now), 1763486400);
  const d = SR.parseMessage(M("💎 SCHATZ GEFUNDEN – Z",'DATA: {"preis":5,"gewinn":40,"ende":"'+(now+3600)+'"}'));
  assert.strictEqual(d.ende, now+3600); assert.ok(SR.endetBald(d, now));
  const e = SR.parseMessage(M("💎 SCHATZ GEFUNDEN – Z","**Preis:** 5 €\n**Gewinn netto:** 40 €\n**Endet:** "+(now+600)*1000));
  assert.strictEqual(e.ende, now+600);
});
t("Fix 7: Ampel aus Tags", () => {
  const b = "**Preis:** 5 €\n**Gewinn netto:** 40 €";
  assert.strictEqual(SR.parseMessage(M("💎 SCHATZ GEFUNDEN – Z", b, {tags:["moneybag","red_circle"]})), null);
  assert.strictEqual(SR.parseMessage(M("💎 SCHATZ GEFUNDEN – Z", b, {tags:["yellow_circle"]})).ampel, "gelb");
  assert.strictEqual(SR.parseMessage(M("⏰ Endet in 5 Min – Z", "", {tags:["green_circle"]})).ampel, "gruen");
  assert.strictEqual(SR.parseMessage(M("💎 SCHATZ GEFUNDEN – Z", "**Ampel:** Grün\n"+b, {tags:["red_circle"]})).ampel, "gruen"); // Ampel-Zeile hat Vorrang
});
t("Fix 8: Service Worker cached nur ok, Manifest ohne maskable", () => {
  const sw = fs.readFileSync(path.join(__dirname,"..","sw.js"),"utf8");
  assert.ok(/if \(r\.ok\)/.test(sw));
  const mf = JSON.parse(fs.readFileSync(path.join(__dirname,"..","manifest.webmanifest"),"utf8"));
  assert.ok(mf.icons.every(i => !/maskable/.test(i.purpose||"")));
  assert.ok(mf.icons.some(i => i.sizes==="512x512" && i.purpose==="any"));
});
t("Fix 9: Rechner bei 0 Stunden", () => {
  const base = {verkauf:220,teilewert:60,gebuehr:13,versandRein:6,versandRaus:6,ersatzteile:30,stunden:0,stundensatz:15,kollege:25,wunsch:40};
  const r = SR.calc(base); assert.strictEqual(r.proStd, null); assert.strictEqual(r.ampel, "gruen"); // bei Max-EK genau Wunschgewinn
  assert.strictEqual(SR.calc(Object.assign({},base,{angebot:120})).ampel, "gelb"); // Gewinn > 0, < Wunsch
  assert.strictEqual(SR.calc(Object.assign({},base,{angebot:160})).ampel, "rot");
});
console.log(`\n${n} Testgruppen bestanden.`);
